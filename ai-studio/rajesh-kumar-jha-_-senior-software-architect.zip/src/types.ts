import { LucideIcon } from 'lucide-react';

export interface Project {
  title: string;
  description: string;
  tech: { name: string; logo: string }[];
  github?: string;
  link?: string;
  image: string;
}

export interface Experience {
  company: string;
  logo: string;
  role: string;
  period: string;
  location: string;
  description: string[];
}

export interface SkillCategory {
  title: string;
  icon: LucideIcon;
  skills: { name: string; logo: string }[];
}

export interface PersonalProject {
  title: string;
  category: string;
  description: string;
  icon: LucideIcon;
  link: string;
  color: string;
}

export interface BrandingProject {
  name: string;
  description: string;
  icon: LucideIcon;
  color: string;
  tags: string[];
  image: string;
}

export interface Hobby {
  name: string;
  icon: string;
}
