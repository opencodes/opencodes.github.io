import { motion } from 'motion/react';
import { Palette } from 'lucide-react';
import { BRANDING_PROJECTS } from '../constants';

export const BrandingSection = () => {
  return (
    <section id="branding" className="py-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 flex items-center justify-center">
            <Palette className="mr-3 text-indigo-500" /> Creative Branding
          </h2>
          <p className="text-slate-500 max-w-2xl mx-auto">
            A collection of brand identities and visual concepts I've designed as a creative outlet. 
            Exploring the intersection of design, psychology, and storytelling.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {BRANDING_PROJECTS.map((brand, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              whileHover={{ y: -10 }}
              className="glass rounded-3xl overflow-hidden group border border-slate-200 dark:border-slate-800"
            >
              <div className={`h-40 bg-gradient-to-br ${brand.color} flex items-center justify-center relative overflow-hidden`}>
                <brand.icon className="w-16 h-16 text-white/20 absolute -right-4 -bottom-4 rotate-12" />
                <brand.icon className="w-12 h-12 text-white drop-shadow-lg relative z-10" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 group-hover:text-indigo-500 transition-colors">{brand.name}</h3>
                <p className="text-slate-600 dark:text-slate-400 text-xs mb-4 line-clamp-3 leading-relaxed">
                  {brand.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {brand.tags.map((tag, j) => (
                    <span key={j} className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      #{tag.replace(/\s+/g, '')}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
