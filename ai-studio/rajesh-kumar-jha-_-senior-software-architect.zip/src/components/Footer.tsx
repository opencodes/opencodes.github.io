import { Github, Linkedin, Mail } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="py-12 bg-white dark:bg-slate-950 border-t border-slate-100 dark:border-slate-900">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
        <div>
          <p className="text-xl font-bold tracking-tighter text-gradient mb-2">RKJ.</p>
          <p className="text-sm text-slate-500">© 2026 Rajesh Kumar Jha. All rights reserved.</p>
        </div>
        <div className="flex space-x-6">
          <a href="https://github.com/opencodes" className="text-slate-400 hover:text-indigo-500 transition-colors"><Github /></a>
          <a href="https://www.linkedin.com/in/rkjha-architect/" className="text-slate-400 hover:text-indigo-500 transition-colors"><Linkedin /></a>
          <a href="mailto:rajeshk@gmail.com" className="text-slate-400 hover:text-indigo-500 transition-colors"><Mail /></a>
        </div>
        <div className="flex space-x-8 text-sm font-medium">
          <a href="#" className="hover:text-indigo-500 transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-indigo-500 transition-colors">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};
