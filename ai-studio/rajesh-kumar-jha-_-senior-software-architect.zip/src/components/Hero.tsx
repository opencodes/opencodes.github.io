import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ChevronRight, Download, Cpu, Code2 } from 'lucide-react';

export const Hero = () => {
  const [text, setText] = useState('');
  const fullText = "Architecting Future-Proof Systems.";
  
  useEffect(() => {
    let i = 0;
    const timer = setInterval(() => {
      setText(fullText.slice(0, i));
      i++;
      if (i > fullText.length) clearInterval(timer);
    }, 100);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full -z-10">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-700" />
      </div>

      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 text-xs font-bold mb-6">
            <span className="relative flex h-2 w-2 mr-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
            </span>
            Available for Strategic Roles
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6 leading-tight min-h-[150px] md:min-h-[220px]">
            {text.split(' ').map((word, i) => (
              <span key={i} className={word === 'Future-Proof' ? 'text-gradient' : ''}>
                {word}{' '}
              </span>
            ))}
            <span className="animate-pulse">|</span>
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-400 mb-8 max-w-lg leading-relaxed">
            I'm Rajesh Kumar Jha, a Senior Software Architect dedicated to building 
            scalable distributed systems and high-performance user experiences.
          </p>
          <div className="flex flex-wrap gap-4">
            <a href="#projects" className="px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition-all shadow-lg shadow-indigo-500/25 flex items-center">
              View Projects <ChevronRight className="ml-2 w-4 h-4" />
            </a>
            <button className="px-8 py-4 glass rounded-xl font-bold flex items-center hover:bg-white/10 transition-all">
              Download Resume <Download className="ml-2 w-4 h-4" />
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="relative hidden md:block"
        >
          <div className="relative z-10 rounded-3xl overflow-hidden border-8 border-white/10 shadow-2xl animate-float">
            <img 
              src="https://picsum.photos/seed/architect/600/700" 
              alt="Rajesh Kumar Jha" 
              className="w-full h-auto grayscale hover:grayscale-0 transition-all duration-700"
              referrerPolicy="no-referrer"
            />
          </div>
          {/* Decorative floating cards */}
          <div className="absolute -top-6 -right-6 glass p-4 rounded-2xl shadow-xl z-20">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-lg">
                <Cpu className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-xs font-bold">Microservices</p>
                <p className="text-[10px] opacity-60">Spring Cloud Expert</p>
              </div>
            </div>
          </div>
          <div className="absolute -bottom-6 -left-6 glass p-4 rounded-2xl shadow-xl z-20">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg">
                <Code2 className="w-5 h-5 text-indigo-600" />
              </div>
              <div>
                <p className="text-xs font-bold">Full Stack</p>
                <p className="text-[10px] opacity-60">React & Node.js</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
