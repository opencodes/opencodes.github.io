import { motion } from 'motion/react';
import { ExternalLink, Github } from 'lucide-react';
import { PROJECTS } from '../constants';

export const Projects = () => {
  return (
    <section id="projects" className="py-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div>
            <h2 className="text-4xl font-bold mb-4">Featured Projects</h2>
            <p className="text-slate-500 max-w-xl">
              A selection of high-impact solutions I've architected for global enterprises and startups.
            </p>
          </div>
          <a href="https://github.com/opencodes" target="_blank" className="flex items-center text-indigo-500 font-bold hover:underline">
            View all on GitHub <ExternalLink className="ml-2 w-4 h-4" />
          </a>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {PROJECTS.map((project, i) => (
            <motion.div 
              key={i}
              whileHover={{ y: -10 }}
              className="group relative rounded-3xl overflow-hidden shadow-xl"
            >
              <div className="aspect-video overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-slate-950/60 to-transparent p-8 flex flex-col justify-end">
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tech.map((t, j) => (
                    <span key={j} className="flex items-center px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-[10px] font-bold text-white uppercase tracking-wider">
                      <img src={t.logo} alt={t.name} className="w-3 h-3 mr-1.5 object-contain invert" referrerPolicy="no-referrer" />
                      {t.name}
                    </span>
                  ))}
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">{project.title}</h3>
                <p className="text-slate-300 text-sm mb-6 line-clamp-2">
                  {project.description}
                </p>
                <div className="flex space-x-4">
                  <a href={project.link} className="p-3 bg-white text-slate-900 rounded-xl hover:bg-indigo-500 hover:text-white transition-all">
                    <ExternalLink className="w-5 h-5" />
                  </a>
                  <a href="https://github.com/opencodes" className="p-3 bg-white/10 backdrop-blur-md text-white rounded-xl hover:bg-white/20 transition-all">
                    <Github className="w-5 h-5" />
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
