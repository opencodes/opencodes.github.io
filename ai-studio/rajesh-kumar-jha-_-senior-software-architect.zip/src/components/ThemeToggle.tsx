import { Sun, Moon } from 'lucide-react';

interface ThemeToggleProps {
  isDark: boolean;
  toggle: () => void;
}

export const ThemeToggle = ({ isDark, toggle }: ThemeToggleProps) => (
  <button 
    onClick={toggle}
    className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
    aria-label="Toggle theme"
  >
    {isDark ? <Sun className="w-5 h-5 text-yellow-500" /> : <Moon className="w-5 h-5 text-slate-700" />}
  </button>
);
