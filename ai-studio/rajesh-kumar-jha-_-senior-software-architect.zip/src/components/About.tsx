import { motion } from 'motion/react';
import { User } from 'lucide-react';

export const About = () => {
  return (
    <section id="about" className="py-24 bg-slate-50 dark:bg-slate-900/50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-8 flex items-center">
              <User className="mr-3 text-indigo-500" /> Professional Summary
            </h2>
            <div className="space-y-6 text-slate-600 dark:text-slate-400 leading-relaxed text-lg">
              <p>
                I am a highly accomplished and results-driven Software Professional with extensive experience in 
                architecture design, end-to-end solution development, and technical leadership.
              </p>
              <p>
                Throughout my career at global giants like <strong>Cisco</strong>, <strong>JP Morgan & Chase</strong>, 
                and <strong>Walmart Labs</strong>, I have proven my ability to lead cross-functional engineering teams 
                and drive technical innovation.
              </p>
              <p>
                My passion lies in leveraging deep expertise in microservices with Spring Cloud, micro frontends, 
                and modern full-stack development to architect transformative, high-scale applications that 
                solve real-world business challenges.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'Years Experience', value: '12+' },
              { label: 'Projects Delivered', value: '50+' },
              { label: 'Companies', value: '6+' },
              { label: 'Tech Stack', value: '20+' },
            ].map((stat, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -5 }}
                className="glass p-8 rounded-2xl text-center"
              >
                <p className="text-3xl font-bold text-indigo-500 mb-1">{stat.value}</p>
                <p className="text-sm font-medium opacity-60">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
