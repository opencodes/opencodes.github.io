import { motion } from 'motion/react';
import { SKILLS } from '../constants';

export const Skills = () => {
  return (
    <section id="skills" className="py-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Technical Arsenal</h2>
          <p className="text-slate-500 max-w-2xl mx-auto">
            A comprehensive overview of the technologies and methodologies I've mastered over a decade of engineering.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {SKILLS.map((cat, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass p-8 rounded-3xl hover:border-indigo-500/50 transition-all group"
            >
              <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/30 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <cat.icon className="w-6 h-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">{cat.title}</h3>
              <div className="flex flex-wrap gap-3">
                {cat.skills.map((skill, j) => (
                  <div key={j} className="flex items-center px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-medium group/skill hover:bg-indigo-500 hover:text-white transition-all">
                    <img src={skill.logo} alt={skill.name} className="w-4 h-4 mr-2 object-contain dark:invert" referrerPolicy="no-referrer" />
                    {skill.name}
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
