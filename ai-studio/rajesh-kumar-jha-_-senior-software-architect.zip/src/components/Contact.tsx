import { Mail, Linkedin, Smartphone } from 'lucide-react';

export const Contact = () => {
  return (
    <section id="contact" className="py-24 bg-indigo-600 text-white overflow-hidden relative">
      {/* Decorative circles */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full -mr-48 -mt-48 blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-indigo-900/30 rounded-full -ml-48 -mb-48 blur-3xl" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold mb-8 leading-tight">
              Let's build something <br /> extraordinary together.
            </h2>
            <p className="text-indigo-100 text-lg mb-12 max-w-md">
              Whether you're looking for architectural guidance, a technical lead, or a full-stack expert, 
              I'm always open to discussing new opportunities.
            </p>
            
            <div className="space-y-6">
              <a href="mailto:rajeshk@gmail.com" className="flex items-center group">
                <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mr-4 group-hover:bg-white group-hover:text-indigo-600 transition-all">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest opacity-60">Email Me</p>
                  <p className="text-xl font-bold">rajeshk@gmail.com</p>
                </div>
              </a>
              <a href="https://www.linkedin.com/in/rkjha-architect/" target="_blank" className="flex items-center group">
                <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mr-4 group-hover:bg-white group-hover:text-indigo-600 transition-all">
                  <Linkedin className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest opacity-60">LinkedIn</p>
                  <p className="text-xl font-bold">rkjha-architect</p>
                </div>
              </a>
              <div className="flex items-center group">
                <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mr-4">
                  <Smartphone className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest opacity-60">Call Me</p>
                  <p className="text-xl font-bold">+91-7022358966</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl p-8 md:p-10 text-slate-900 shadow-2xl">
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold">Full Name</label>
                  <input type="text" className="w-full px-4 py-3 bg-slate-100 rounded-xl border-none focus:ring-2 focus:ring-indigo-500 transition-all" placeholder="John Doe" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold">Email Address</label>
                  <input type="email" className="w-full px-4 py-3 bg-slate-100 rounded-xl border-none focus:ring-2 focus:ring-indigo-500 transition-all" placeholder="john@example.com" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold">Subject</label>
                <input type="text" className="w-full px-4 py-3 bg-slate-100 rounded-xl border-none focus:ring-2 focus:ring-indigo-500 transition-all" placeholder="Project Inquiry" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold">Message</label>
                <textarea rows={4} className="w-full px-4 py-3 bg-slate-100 rounded-xl border-none focus:ring-2 focus:ring-indigo-500 transition-all" placeholder="Tell me about your project..."></textarea>
              </div>
              <button className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition-all shadow-lg shadow-indigo-500/25">
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};
