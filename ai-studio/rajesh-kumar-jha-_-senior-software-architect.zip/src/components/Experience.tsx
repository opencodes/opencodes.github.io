import { motion } from 'motion/react';
import { Briefcase, ChevronRight } from 'lucide-react';
import { EXPERIENCE } from '../constants';

export const Experience = () => {
  return (
    <section id="experience" className="py-24 bg-slate-50 dark:bg-slate-900/50">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 flex items-center justify-center">
            <Briefcase className="mr-3 text-indigo-500" /> Career Journey
          </h2>
        </div>

        <div className="space-y-12">
          {EXPERIENCE.map((exp, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative pl-8 border-l-2 border-indigo-500/30"
            >
              <div className="absolute -left-[9px] top-0 w-4 h-4 bg-indigo-500 rounded-full border-4 border-white dark:border-slate-900" />
              <div className="glass p-8 rounded-3xl">
                <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-6 gap-4">
                  <div className="flex items-center">
                    <div className="w-16 h-16 bg-white rounded-2xl p-2 shadow-sm mr-4 flex items-center justify-center overflow-hidden">
                      <img src={exp.logo} alt={exp.company} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold">{exp.role}</h3>
                      <p className="text-indigo-500 font-bold">{exp.company}</p>
                    </div>
                  </div>
                  <div className="text-left md:text-right text-sm">
                    <p className="font-bold">{exp.period}</p>
                    <p className="opacity-60">{exp.location}</p>
                  </div>
                </div>
                <ul className="space-y-3">
                  {exp.description.map((item, j) => (
                    <li key={j} className="flex items-start text-slate-600 dark:text-slate-400">
                      <ChevronRight className="w-5 h-5 text-indigo-500 shrink-0 mt-0.5 mr-2" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
