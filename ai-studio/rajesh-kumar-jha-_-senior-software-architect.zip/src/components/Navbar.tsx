import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, ChevronDown } from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';

interface NavLinkItem {
  name: string;
  href?: string;
  subLinks?: { name: string; href: string }[];
}

interface NavbarProps {
  isDark: boolean;
  toggleTheme: () => void;
}

export const Navbar = ({ isDark, toggleTheme }: NavbarProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSubMenu, setActiveSubMenu] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks: NavLinkItem[] = [
    { name: 'About', href: '#about' },
    { 
      name: 'Expertise', 
      subLinks: [
        { name: 'Skills', href: '#skills' },
        { name: 'Experience', href: '#experience' },
      ]
    },
    { 
      name: 'Portfolio', 
      subLinks: [
        { name: 'Projects', href: '#projects' },
        { name: 'Branding', href: '#branding' },
        { name: 'Personal Work', href: '#beyond' },
      ]
    },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? 'glass py-3 shadow-lg' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <a href="#" className="text-xl font-bold tracking-tighter text-gradient">
          RKJ.
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <div 
              key={link.name} 
              className="relative group"
              onMouseEnter={() => link.subLinks && setActiveSubMenu(link.name)}
              onMouseLeave={() => setActiveSubMenu(null)}
            >
              {link.href ? (
                <a 
                  href={link.href}
                  className="text-sm font-medium hover:text-indigo-500 transition-colors flex items-center gap-1"
                >
                  {link.name}
                </a>
              ) : (
                <button className="text-sm font-medium hover:text-indigo-500 transition-colors flex items-center gap-1">
                  {link.name}
                  <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${activeSubMenu === link.name ? 'rotate-180' : ''}`} />
                </button>
              )}

              {/* Desktop Submenu */}
              <AnimatePresence>
                {link.subLinks && activeSubMenu === link.name && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    transition={{ duration: 0.2 }}
                    className="absolute top-full left-0 mt-2 w-48 glass rounded-xl shadow-xl border border-white/10 overflow-hidden"
                  >
                    <div className="py-2">
                      {link.subLinks.map((sub) => (
                        <a
                          key={sub.name}
                          href={sub.href}
                          className="block px-4 py-2 text-sm hover:bg-indigo-500/10 hover:text-indigo-500 transition-colors"
                        >
                          {sub.name}
                        </a>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
          <ThemeToggle isDark={isDark} toggle={toggleTheme} />
        </div>

        {/* Mobile Toggle */}
        <div className="md:hidden flex items-center space-x-4">
          <ThemeToggle isDark={isDark} toggle={toggleTheme} />
          <button onClick={() => setIsOpen(!isOpen)} className="p-2">
            {isOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass border-t border-white/10 overflow-hidden"
          >
            <div className="flex flex-col p-6 space-y-4">
              {navLinks.map((link) => (
                <div key={link.name} className="flex flex-col">
                  {link.href ? (
                    <a 
                      href={link.href} 
                      onClick={() => setIsOpen(false)}
                      className="text-lg font-medium py-2"
                    >
                      {link.name}
                    </a>
                  ) : (
                    <>
                      <button 
                        onClick={() => setActiveSubMenu(activeSubMenu === link.name ? null : link.name)}
                        className="text-lg font-medium py-2 flex justify-between items-center w-full"
                      >
                        {link.name}
                        <ChevronDown className={`w-5 h-5 transition-transform duration-200 ${activeSubMenu === link.name ? 'rotate-180' : ''}`} />
                      </button>
                      <AnimatePresence>
                        {activeSubMenu === link.name && link.subLinks && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="pl-4 flex flex-col space-y-2 overflow-hidden"
                          >
                            {link.subLinks.map((sub) => (
                              <a
                                key={sub.name}
                                href={sub.href}
                                onClick={() => setIsOpen(false)}
                                className="text-base text-gray-500 dark:text-gray-400 py-1"
                              >
                                {sub.name}
                              </a>
                            ))}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </>
                  )}
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
