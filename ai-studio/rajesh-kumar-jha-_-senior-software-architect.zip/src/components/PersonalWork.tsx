import { motion } from 'motion/react';
import { User } from 'lucide-react';
import { PERSONAL_PROJECTS, HOBBIES } from '../constants';

export const PersonalWork = () => {
  return (
    <section id="beyond" className="py-24 bg-slate-50 dark:bg-slate-900/50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Beyond the Code</h2>
          <p className="text-slate-500 max-w-2xl mx-auto">
            When I'm not architecting systems, I'm creating content, building personal tools, and exploring the world.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-20">
          {PERSONAL_PROJECTS.map((project, i) => (
            <motion.a 
              key={i}
              href={project.link}
              target="_blank"
              whileHover={{ y: -10 }}
              className="glass p-8 rounded-3xl block group border-b-4 border-transparent hover:border-indigo-500 transition-all"
            >
              <div className={`w-14 h-14 ${project.color} rounded-2xl flex items-center justify-center mb-6 text-white shadow-lg`}>
                <project.icon className="w-7 h-7" />
              </div>
              <p className="text-xs font-bold uppercase tracking-widest text-indigo-500 mb-2">{project.category}</p>
              <h3 className="text-2xl font-bold mb-4 group-hover:text-indigo-500 transition-colors">{project.title}</h3>
              <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">
                {project.description}
              </p>
            </motion.a>
          ))}
        </div>

        <div className="glass p-10 rounded-[40px] relative overflow-hidden">
          <div className="absolute top-0 right-0 p-10 opacity-10">
            <User className="w-40 h-40" />
          </div>
          <div className="relative z-10">
            <h3 className="text-2xl font-bold mb-8 flex items-center">
              <span className="mr-3">🏝️</span> Out of Office
            </h3>
            <div className="flex flex-wrap gap-4">
              {HOBBIES.map((hobby, i) => (
                <div 
                  key={i} 
                  className="px-6 py-4 bg-white dark:bg-slate-800 rounded-2xl shadow-sm flex items-center space-x-3 hover:scale-105 transition-transform cursor-default"
                >
                  <span className="text-2xl">{hobby.icon}</span>
                  <span className="font-bold text-sm">{hobby.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
