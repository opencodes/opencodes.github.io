import { 
  Github, 
  Globe, 
  Smartphone, 
  Layers, 
  Terminal, 
  Database,
  Sparkles,
  Brush,
  Palette
} from 'lucide-react';
import { Project, Experience, SkillCategory, PersonalProject, BrandingProject, Hobby } from './types';

export const PROJECTS: Project[] = [
  {
    title: "Enterprise Workflow Orchestration",
    description: "Architected a complex enterprise solution for STC integrating Full Stack, Angular, and Camunda BPMN for high-scale telecom workflows.",
    tech: [
      { name: "Node.js", logo: "https://cdn.simpleicons.org/nodedotjs/339933" },
      { name: "Angular", logo: "https://cdn.simpleicons.org/angular/DD0031" },
      { name: "Camunda", logo: "https://cdn.simpleicons.org/camunda/FF6600" },
      { name: "REST APIs", logo: "https://cdn.simpleicons.org/insomnia/4000BF" }
    ],
    link: "#",
    image: "https://picsum.photos/seed/workflow/800/600"
  },
  {
    title: "Wholesale Banking Platform",
    description: "Led the ground-up design of a modular banking platform using Micro-frontend architecture and Spring Cloud microservices.",
    tech: [
      { name: "React", logo: "https://cdn.simpleicons.org/react/61DAFB" },
      { name: "Spring Boot", logo: "https://cdn.simpleicons.org/springboot/6DB33F" },
      { name: "Spring Cloud", logo: "https://cdn.simpleicons.org/spring/6DB33F" },
      { name: "Kafka", logo: "https://cdn.simpleicons.org/apachekafka/231F20" }
    ],
    link: "#",
    image: "https://picsum.photos/seed/banking/800/600"
  },
  {
    title: "GUIDE Mobile App",
    description: "Engineered a React Native application for Walmart associates featuring facial recognition and location-based services.",
    tech: [
      { name: "React Native", logo: "https://cdn.simpleicons.org/react/61DAFB" },
      { name: "React", logo: "https://cdn.simpleicons.org/react/61DAFB" },
      { name: "Firebase", logo: "https://cdn.simpleicons.org/firebase/FFCA28" },
      { name: "Android", logo: "https://cdn.simpleicons.org/android/3DDC84" }
    ],
    link: "#",
    image: "https://picsum.photos/seed/mobile/800/600"
  },
  {
    title: "Citibank CIAP Portal",
    description: "Developed a high-performance SPA for server administration, focusing on intuitive UX and robust security.",
    tech: [
      { name: "Angular", logo: "https://cdn.simpleicons.org/angular/DD0031" },
      { name: "HTML5", logo: "https://cdn.simpleicons.org/html5/E34F26" },
      { name: "CSS3", logo: "https://cdn.simpleicons.org/css3/1572B6" },
      { name: "JavaScript", logo: "https://cdn.simpleicons.org/javascript/F7DF1E" }
    ],
    link: "#",
    image: "https://picsum.photos/seed/admin/800/600"
  }
];

export const EXPERIENCE: Experience[] = [
  {
    company: "Cisco",
    logo: "https://cdn.simpleicons.org/cisco/049BAF",
    role: "Senior Consulting Engineer",
    period: "Jul 2022 – Present",
    location: "Bengaluru, India",
    description: [
      "Architected enterprise solutions for STC using Full Stack and Camunda BPMN.",
      "Designed scalable Node.js RESTful APIs for complex workflow orchestration.",
      "Spearheaded Python automation for DU Telecom, enhancing operational efficiency.",
      "Provided technical leadership to cross-functional internal teams."
    ]
  },
  {
    company: "JP Morgan & Chase",
    logo: "https://cdn.simpleicons.org/jpmorgan/000000",
    role: "Application Developer - Senior Associate",
    period: "Dec 2019 – May 2022",
    location: "Bengaluru, India",
    description: [
      "Led architectural design of a wholesale banking platform from scratch.",
      "Implemented cloud-native microservices using Spring Boot and Spring Cloud.",
      "Championed Micro Frontend Architecture to decompose monoliths into agile units.",
      "Managed inter-service communication using Kafka and Feign Clients."
    ]
  },
  {
    company: "Walmart Labs",
    logo: "https://cdn.simpleicons.org/walmart/0071CE",
    role: "Individual Contributor 4",
    period: "Jan 2019 – Dec 2019",
    location: "Bengaluru, India",
    description: [
      "Designed and developed the GUIDE Mobile App using React Native.",
      "Integrated real-time employee profiles and store layouts via diverse APIs.",
      "Implemented facial recognition and location-based services.",
      "Oversaw deployment to Walmart's private app store."
    ]
  }
];

export const SKILLS: SkillCategory[] = [
  {
    title: "Architecture",
    icon: Layers,
    skills: [
      { name: "Microservices", logo: "https://cdn.simpleicons.org/spring/6DB33F" },
      { name: "Micro Frontends", logo: "https://cdn.simpleicons.org/modulefederation/0175C2" },
      { name: "System Design", logo: "https://cdn.simpleicons.org/diagramsdotnet/F08705" },
      { name: "Cloud-Native", logo: "https://cdn.simpleicons.org/cloudnativecomputingfoundation/0086FF" },
      { name: "Scalability", logo: "https://cdn.simpleicons.org/googlecloud/4285F4" }
    ]
  },
  {
    title: "Frontend",
    icon: Globe,
    skills: [
      { name: "React", logo: "https://cdn.simpleicons.org/react/61DAFB" },
      { name: "Angular", logo: "https://cdn.simpleicons.org/angular/DD0031" },
      { name: "React Native", logo: "https://cdn.simpleicons.org/react/61DAFB" },
      { name: "Flutter", logo: "https://cdn.simpleicons.org/flutter/02569B" },
      { name: "Tailwind CSS", logo: "https://cdn.simpleicons.org/tailwindcss/06B6D4" },
      { name: "Material UI", logo: "https://cdn.simpleicons.org/mui/007FFF" }
    ]
  },
  {
    title: "Backend",
    icon: Terminal,
    skills: [
      { name: "Java", logo: "https://cdn.simpleicons.org/oracle/F80000" },
      { name: "Spring Boot", logo: "https://cdn.simpleicons.org/springboot/6DB33F" },
      { name: "Node.js", logo: "https://cdn.simpleicons.org/nodedotjs/339933" },
      { name: "Express", logo: "https://cdn.simpleicons.org/express/000000" },
      { name: "PHP", logo: "https://cdn.simpleicons.org/php/777BB4" },
      { name: "Python", logo: "https://cdn.simpleicons.org/python/3776AB" }
    ]
  },
  {
    title: "Databases",
    icon: Database,
    skills: [
      { name: "MongoDB", logo: "https://cdn.simpleicons.org/mongodb/47A248" },
      { name: "MySQL", logo: "https://cdn.simpleicons.org/mysql/4479A1" },
      { name: "Redis", logo: "https://cdn.simpleicons.org/redis/DC382D" },
      { name: "Elastic Search", logo: "https://cdn.simpleicons.org/elasticsearch/005571" }
    ]
  }
];

export const PERSONAL_PROJECTS: PersonalProject[] = [
  {
    title: "Tech with Rajesh",
    category: "YouTube Channel",
    description: "Sharing insights on system design, microservices, and career growth in tech with 10k+ subscribers.",
    icon: Github,
    link: "https://youtube.com",
    color: "bg-red-500"
  },
  {
    title: "Architect's Journal",
    category: "Personal Blog",
    description: "Weekly deep dives into software patterns, leadership, and the future of cloud-native engineering.",
    icon: Globe,
    link: "https://blog.rajesh.com",
    color: "bg-blue-500"
  },
  {
    title: "Mindful Coding",
    category: "Mobile App",
    description: "A productivity app designed for developers to manage deep work sessions and mental well-being.",
    icon: Smartphone,
    link: "#",
    color: "bg-green-500"
  }
];

export const HOBBIES: Hobby[] = [
  { name: "Photography", icon: "📸" },
  { name: "Mountain Trekking", icon: "🏔️" },
  { name: "Chess Strategy", icon: "♟️" },
  { name: "Urban Sketching", icon: "🎨" },
  { name: "Cooking Fusion", icon: "🍳" },
];

export const BRANDING_PROJECTS: BrandingProject[] = [
  {
    name: "Nebula Coffee",
    description: "A space-themed specialty coffee roastery focusing on cosmic blends and futuristic packaging.",
    icon: Sparkles,
    color: "from-purple-600 to-indigo-600",
    tags: ["Visual Identity", "Packaging", "Logo Design"],
    image: "https://picsum.photos/seed/nebula/800/600"
  },
  {
    name: "EcoStride",
    description: "Sustainable footwear brand identity emphasizing minimalist design and earth-friendly materials.",
    icon: Brush,
    color: "from-emerald-500 to-teal-600",
    tags: ["Sustainable Branding", "Typography", "Web Design"],
    image: "https://picsum.photos/seed/eco/800/600"
  },
  {
    name: "Zenith Tech",
    description: "A high-end audio equipment brand that blends brutalist architecture with modern sound technology.",
    icon: Palette,
    color: "from-slate-700 to-slate-900",
    tags: ["Industrial Design", "Brand Strategy", "Logo"],
    image: "https://picsum.photos/seed/zenith/800/600"
  },
  {
    name: "Bloom & Wild",
    description: "An artisanal florist identity that uses vibrant floral patterns and elegant serif typography.",
    icon: Sparkles,
    color: "from-pink-500 to-rose-600",
    tags: ["Floral Design", "Illustration", "Identity"],
    image: "https://picsum.photos/seed/bloom/800/600"
  }
];
