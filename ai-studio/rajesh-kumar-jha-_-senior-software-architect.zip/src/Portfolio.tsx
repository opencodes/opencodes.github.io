import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Skills } from './components/Skills';
import { Experience } from './components/Experience';
import { Projects } from './components/Projects';
import { BrandingSection } from './components/BrandingSection';
import { PersonalWork } from './components/PersonalWork';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';

const sectionVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: { 
    opacity: 1, 
    y: 0, 
    transition: { 
      duration: 0.8, 
      ease: [0.25, 0.1, 0.25, 1] 
    } 
  }
};

const ScrollSection = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    initial="hidden"
    whileInView="visible"
    viewport={{ once: true, margin: "-10%" }}
    variants={sectionVariants}
  >
    {children}
  </motion.div>
);

export default function Portfolio() {
  const [isDark, setIsDark] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return true;
  });

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
      document.documentElement.style.colorScheme = 'dark';
      document.documentElement.setAttribute('data-theme', 'dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
      document.documentElement.style.colorScheme = 'light';
      document.documentElement.setAttribute('data-theme', 'light');
      localStorage.setItem('theme', 'light');
    }
  }, [isDark]);

  return (
    <div className={`min-h-screen font-sans ${isDark ? 'dark' : ''}`}>
      <Navbar isDark={isDark} toggleTheme={() => setIsDark(!isDark)} />
      <main>
        <Hero />
        <ScrollSection><About /></ScrollSection>
        <ScrollSection><Skills /></ScrollSection>
        <ScrollSection><Experience /></ScrollSection>
        <ScrollSection><Projects /></ScrollSection>
        <ScrollSection><BrandingSection /></ScrollSection>
        <ScrollSection><PersonalWork /></ScrollSection>
        <ScrollSection><Contact /></ScrollSection>
      </main>
      <Footer />
    </div>
  );
}
