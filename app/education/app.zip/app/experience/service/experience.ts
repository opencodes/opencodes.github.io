export interface Experience{
    title : string,
    content : string,
    experience : []
}