import {Component} from '@angular/core';

import {ExperienceService} from 'app/experience/service/experience.service';

@Component({
    templateUrl : "./app/experience/html/experience.html",
    providers:[ExperienceService]
})

export class ExperienceComponent{
    constructor(private _experienceService:ExperienceService){
        
    }
    title = "Experience";
    ngOnInit(){
        this.experience = this._experienceService.getExperience();
    }
}

