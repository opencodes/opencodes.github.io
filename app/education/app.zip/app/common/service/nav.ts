export class Nav{
    title : string;
    href : string;    
};