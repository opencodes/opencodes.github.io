import {Component} from '@angular/core';

@Component({
  templateUrl: './app/auth/html/login.html',
  styleUrls: ['./app/auth/css/login.css']
})

export class LoginComponent  { 
	title = 'Login Component'; 
}