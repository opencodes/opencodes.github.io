export interface Skill{
    title : string,
    content : string,
    tags: [],
    skills : []
}