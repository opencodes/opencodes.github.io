export interface Fun{
    title : string,
    content : string,
    education : []
}