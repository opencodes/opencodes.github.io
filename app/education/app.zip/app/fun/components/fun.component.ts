import {Component} from '@angular/core';

import {FunService} from 'app/fun/service/fun.service';

@Component({
    templateUrl : "./app/fun/html/fun.html",
    providers:[FunService]
})

export class FunComponent{
    constructor(private _funService:FunService){
        
    }
    title = "Fun";
    ngOnInit(){
        this.fun = this._funService.getFun();
    }
}

