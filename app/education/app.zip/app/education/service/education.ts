export interface Education{
    title : string;
    content : string;
    education : [];
}