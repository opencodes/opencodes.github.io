import {Resume} from './resume';

export const RESUME : Resume[] = {
     "title":"Education",
     "content":"I have experties on various web technologies.",
     
  }