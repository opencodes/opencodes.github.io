export interface Resume{
    title : string,
    content : string,
}