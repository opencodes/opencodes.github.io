import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';


import { AppComponent }  from './app.component';
import { RoutingConfig }  from './routing.config';
//Common
import { PageNotFoundComponent }  from './common/components/page.not.found.component';
import { PageService} from 'app/common/service/page.service';
//Education
import { EducationComponent }  from './education/components/education.component';
import { EducationService} from 'app/education/service/education.service';
//Experience
import { ExperienceComponent }  from './experience/components/experience.component';
import { ExperienceService} from 'app/experience/service/experience.service';
//Fun
import { FunComponent }  from './fun/components/fun.component';
import { FunService} from 'app/fun/service/fun.service';
//Profile
import { ProfileComponent }  from './profile/components/profile.component';
import { ProfileService} from 'app/profile/service/profile.service';
//Projects
import { ProjectComponent }  from './project/components/project.component';
import { ProjectService} from 'app/project/service/project.service';



@NgModule({
  imports:      [ BrowserModule, RouterModule.forRoot(RoutingConfig) ],
    
  declarations: [ 
      AppComponent,
      EducationComponent, 
      ExperienceComponent, 
      FunComponent, 
      PageNotFoundComponent, 
      ProfileComponent ,
      ProjectComponent],
    
  bootstrap:    [ AppComponent ],
    
  providers:    [ 
      PageService, 
      EducationService, 
      ExperienceService, 
      FunService, 
      ProfileService, 
      ProjectService 
  ]
})
export class AppModule { }
