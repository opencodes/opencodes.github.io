import { Component,OnInit } from '@angular/core';

//Local 
import { Nav } from './common/service/nav';
import {PageService} from './common/service/page.service';



@Component({
  selector: 'my-app',
  templateUrl: './app/app.html',
    providers : [PageService]
})

export class AppComponent implements OnInit {
  title = 'Tour of Heroes';
  topnav: Nav[];
  name = 'Rajesh'; 
  constructor(private _pageService: PageService) { }

  getNavigations(): void {
    this._pageService.getTopNav().then(nav => this.topnav = nav);
  }

  ngOnInit(): void {
    this.getNavigations();
  }

  
}