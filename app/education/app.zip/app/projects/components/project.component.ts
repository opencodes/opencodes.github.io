import {Component} from '@angular/core';

import {ProjectService} from 'app/project/service/project.service';

@Component({
    templateUrl : "./app/project/html/project.html",
    providers:[ProjectService]
})

export class ProjectComponent{
    constructor(private _projectService:ProjectService){
        
    }
    title = "Project";
    ngOnInit(){
        this.project = this._projectService.getProject();
    }
}

