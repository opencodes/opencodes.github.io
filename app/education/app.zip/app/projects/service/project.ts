export interface Project{
    title : string,
    content : string,
    projects : []
}