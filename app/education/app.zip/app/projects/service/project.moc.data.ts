import {Project} from './project';

export const PROJECT : Project[] = {
         "title":"Projects",
         "content":"I have experties on various web technologies.",
         "projects" : {"sapient":[{
               "image" : "assets/images/portfolio/kuoni_logo.png",
               "title" : "Title",
               "url" :"./",
               "description" : "Description"
               },{
               "image" : "assets/images/portfolio/jato_logo.png",
               "title" : "Title",
               "url" :"./",
               "description" : "Description"
               },{
               "image" : "assets/images/portfolio/staples_logo.png",
               "title" : "Title",
               "url" :"./",
               "description" : "Description"
               },{
               "image" : "assets/images/portfolio/coach_logo.png",
               "title" : "Title",
               "url" :"./",
               "description" : "Description"
               },{
               "image" : "assets/images/portfolio/diesel_logo.png",
               "title" : "Title",
               "url" :"./",
               "description" : "Description"
               },{
               "image" : "assets/images/portfolio/johndeere_logo.png",
               "title" : "Title",
               "url" :"./",
               "description" : "Description"
               },{
               "image" : "assets/images/portfolio/tiffany_logo.png",
               "title" : "Title",
               "url" :"./",
               "description" : "Description"
               }]
            ,
            "urbantouch":[{
               "image" : "assets/images/portfolio/urbantouch_logo.png",
               "title" : "Title",
               "url" :"./",
               "description" : "Description"
               }],
            "componence":[{
               "image" : "assets/images/portfolio/papergoods_logo.png",
               "title" : "Title",
               "url" :"./",
               "description" : "Description"
               },{
               "image" : "assets/images/portfolio/yaysave_logo.png",
               "title" : "Title",
               "url" :"./",
               "description" : "Description"
               },{
               "image" : "assets/images/portfolio/watterbobble_logo.png",
               "title" : "Title",
               "url" :"./",
               "description" : "Description"
            }]}


      }