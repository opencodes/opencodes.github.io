import {Component} from '@angular/core';

import {ProfileService} from 'app/profile/service/profile.service';

@Component({
    templateUrl : "./app/profile/html/profile.html",
    providers:[ProfileService]
})

export class ProfileComponent{
    constructor(private _profileService:ProfileService){
        
    }
    title = "Profile";
    ngOnInit(){
        this.profile = this._profileService.getProfile();
        this.profile.fullname = this.profile.name.firstname + this.profile.name.middlename  + this.profile.name.lastname;
    }
}

